const http = require("http");
const fs = require("fs");
const path = require("path");
const crypto = require("crypto");

const PORT = process.env.PORT || 3000;

const RAZORPAY_KEY_ID = process.env.RAZORPAY_KEY_ID;
const RAZORPAY_KEY_SECRET = process.env.RAZORPAY_KEY_SECRET;

const SUPPLIER_API_URL = process.env.SUPPLIER_API_URL;
const SUPPLIER_API_KEY = process.env.SUPPLIER_API_KEY;
const SUPPLIER_MASTER_KEY = process.env.SUPPLIER_MASTER_KEY;

/*
  Put the exact authorized supplier Product PIDs here.
  Do NOT put API secrets in index.html.
*/
const PRODUCTS = {
  hg: {
    "1 Day": "HG_PRODUCT_PID",
    "7 Days": "HG_PRODUCT_PID",
    "10 Days": "HG_PRODUCT_PID",
    "30 Days": "HG_PRODUCT_PID"
  },
  proxy: {
    "1 Day": "PROXY_PRODUCT_PID",
    "3 Days": "PROXY_PRODUCT_PID",
    "7 Days": "PROXY_PRODUCT_PID"
  },
  prime: {
    "3 Days": "PRIME_PRODUCT_PID",
    "7 Days": "PRIME_PRODUCT_PID"
  },
  drip: {
    "1 Day": "DRIP_PRODUCT_PID",
    "3 Days": "DRIP_PRODUCT_PID",
    "7 Days": "DRIP_PRODUCT_PID",
    "15 Days": "DRIP_PRODUCT_PID",
    "30 Days": "DRIP_PRODUCT_PID"
  },
  bala: {
    "1 Hour": "BALA_PRODUCT_PID",
    "2 Hours": "BALA_PRODUCT_PID",
    "3 Hours": "BALA_PRODUCT_PID",
    "6 Hours": "BALA_PRODUCT_PID",
    "12 Hours": "BALA_PRODUCT_PID",
    "24 Hours": "BALA_PRODUCT_PID",
    "48 Hours": "BALA_PRODUCT_PID",
    "78 Hours": "BALA_PRODUCT_PID"
  }
};

const orders = new Map();

function sendJSON(res, status, body) {
  res.writeHead(status, {
    "Content-Type": "application/json",
    "Access-Control-Allow-Origin": "*",
    "Access-Control-Allow-Headers": "Content-Type",
    "Access-Control-Allow-Methods": "GET,POST,OPTIONS"
  });
  res.end(JSON.stringify(body));
}

function body(req) {
  return new Promise((resolve, reject) => {
    let data = "";
    req.on("data", chunk => {
      data += chunk;
      if (data.length > 1000000) {
        req.destroy();
        reject(new Error("Request too large"));
      }
    });
    req.on("end", () => resolve(data));
    req.on("error", reject);
  });
}

async function razorpay(endpoint, method, payload) {
  const auth = Buffer.from(
    `${RAZORPAY_KEY_ID}:${RAZORPAY_KEY_SECRET}`
  ).toString("base64");

  const r = await fetch(`https://api.razorpay.com/v1/${endpoint}`, {
    method,
    headers: {
      Authorization: `Basic ${auth}`,
      "Content-Type": "application/json"
    },
    body: payload ? JSON.stringify(payload) : undefined
  });

  const data = await r.json();
  if (!r.ok) throw new Error(data.error?.description || "Razorpay error");
  return data;
}

async function supplierBuy(type, duration, androidId) {
  const pid = PRODUCTS[type]?.[duration];

  if (!pid || pid.includes("_PRODUCT_PID")) {
    throw new Error("Supplier Product PID is not configured.");
  }

  if (type === "bala" && !androidId) {
    throw new Error("Android ID is required for BALA MOD.");
  }

  const form = new URLSearchParams({
    api_key: SUPPLIER_API_KEY || "",
    action: "buy",
    product_id: pid,
    duration
  });

  if (androidId) form.set("android_id", androidId);

  const r = await fetch(SUPPLIER_API_URL, {
    method: "POST",
    headers: {
      "Content-Type": "application/x-www-form-urlencoded",
      "x-master-key": SUPPLIER_MASTER_KEY || ""
    },
    body: form
  });

  const text = await r.text();
  if (!r.ok) throw new Error(`Supplier HTTP ${r.status}`);

  let data;
  try { data = JSON.parse(text); }
  catch { throw new Error("Supplier returned invalid JSON."); }

  const key =
    data.key ||
    data.license_key ||
    data.license ||
    data.data?.key ||
    data.data?.license_key;

  if (!key) throw new Error("Supplier did not return a key.");

  return key;
}

function validSignature(orderId, paymentId, signature) {
  const expected = crypto
    .createHmac("sha256", RAZORPAY_KEY_SECRET)
    .update(`${orderId}|${paymentId}`)
    .digest("hex");

  const a = Buffer.from(expected);
  const b = Buffer.from(signature || "");
  return a.length === b.length && crypto.timingSafeEqual(a, b);
}

async function createOrder(req, res) {
  try {
    if (!RAZORPAY_KEY_ID || !RAZORPAY_KEY_SECRET) {
      return sendJSON(res, 500, { error: "Razorpay credentials are missing." });
    }

    const data = JSON.parse(await body(req));
    const amount = Number(data.amount);
    const type = String(data.type || "");
    const duration = String(data.duration || "");
    const androidId = String(data.androidId || "");

    if (!Number.isInteger(amount) || amount <= 0)
      return sendJSON(res, 400, { error: "Invalid amount." });

    if (!PRODUCTS[type]?.[duration])
      return sendJSON(res, 400, { error: "Invalid product or duration." });

    if (type === "bala" && !androidId)
      return sendJSON(res, 400, { error: "Android ID is required." });

    const order = await razorpay("orders", "POST", {
      amount: amount * 100,
      currency: "INR",
      receipt: `mayur_${Date.now()}`
    });

    orders.set(order.id, {
      type, duration, androidId, amount, status: "CREATED"
    });

    sendJSON(res, 200, {
      keyId: RAZORPAY_KEY_ID,
      orderId: order.id,
      amount: order.amount,
      currency: order.currency
    });
  } catch (e) {
    sendJSON(res, 500, { error: e.message });
  }
}

async function verify(req, res) {
  try {
    const data = JSON.parse(await body(req));
    const {
      razorpay_order_id: orderId,
      razorpay_payment_id: paymentId,
      razorpay_signature: signature
    } = data;

    const order = orders.get(orderId);
    if (!order) return sendJSON(res, 404, { error: "Order not found." });

    if (!validSignature(orderId, paymentId, signature)) {
      return sendJSON(res, 400, { error: "Payment verification failed." });
    }

    if (order.status === "DELIVERED")
      return sendJSON(res, 200, { success: true, key: order.key });

    const key = await supplierBuy(
      order.type,
      order.duration,
      order.androidId
    );

    order.status = "DELIVERED";
    order.key = key;

    sendJSON(res, 200, { success: true, key });
  } catch (e) {
    sendJSON(res, 500, { error: e.message });
  }
}

const server = http.createServer(async (req, res) => {
  if (req.method === "OPTIONS") {
    res.writeHead(204, {
      "Access-Control-Allow-Origin": "*",
      "Access-Control-Allow-Headers": "Content-Type",
      "Access-Control-Allow-Methods": "GET,POST,OPTIONS"
    });
    return res.end();
  }

  if (req.method === "POST" && req.url === "/api/create-order")
    return createOrder(req, res);

  if (req.method === "POST" && req.url === "/api/verify-payment")
    return verify(req, res);

  let file = req.url === "/" ? "index.html" : req.url.replace(/^\/+/, "");
  file = path.normalize(file);
  if (file.includes("..")) return sendJSON(res, 400, { error: "Bad path." });

  const filePath = path.join(__dirname, "public", file);
  fs.readFile(filePath, (err, data) => {
    if (err) return sendJSON(res, 404, { error: "Not found." });
    res.writeHead(200, {
      "Content-Type": file.endsWith(".html") ? "text/html; charset=utf-8" : "text/plain"
    });
    res.end(data);
  });
});

server.listen(PORT, "0.0.0.0", () =>
  console.log(`Mayur Panel Store listening on ${PORT}`)
);
