# Mayur Panel Store — Auto Reseller

This combines the existing Mayur Panel Store UI with:
- Razorpay Checkout for Add Balance and product purchases
- Server-side Razorpay signature verification
- Razorpay webhook handling
- Supplier reseller API fulfilment after captured payment
- BALA MOD Android ID handling
- Automatic key delivery to the customer

## Important

The supplier API credentials previously pasted into chat should be revoked/rotated.
Put only the new credentials in `.env`.

## Setup

1. Install Node.js 18+.
2. Run:
   npm install
3. Copy `.env.example` to `.env`.
4. Put your NEW Razorpay credentials in `.env`.
5. Put your NEW supplier API credentials in `.env`.
6. Replace every `*_PID` value in `server.js` with the supplier's exact Product PID.
7. Start:
   npm start

## Razorpay webhook

Configure an HTTPS webhook in Razorpay pointing to:

https://YOUR-DOMAIN/api/razorpay/webhook

Use a strong webhook secret and put the same value in `.env`.

Subscribe to payment.captured, order.paid, and payment.failed.

## Supplier response

The code looks for:
- key
- license_key
- activation_key
- data.key
- data.license_key
- data.activation_key

If your supplier returns the key in another field, update `supplierBuy()`.

## Production

The included `data.json` store is for a quick setup/demo. Before real sales, replace it with PostgreSQL/MySQL/MongoDB and add proper authenticated user sessions, transaction locking/idempotency, retries, and an admin order dashboard.

Never trust the browser for payment status or balance. The webhook/server is authoritative.
